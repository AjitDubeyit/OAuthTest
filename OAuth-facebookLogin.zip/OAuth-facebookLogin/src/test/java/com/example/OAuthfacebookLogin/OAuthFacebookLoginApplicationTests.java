package com.example.OAuthfacebookLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OAuthFacebookLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
